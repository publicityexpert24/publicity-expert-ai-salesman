(function () {
	'use strict';

	const root = document.getElementById('peais-salesman-root');
	if (!root || typeof PEAISalesman === 'undefined') return;

	const toggle = document.getElementById('peais-salesman-toggle');
	const panel = document.getElementById('peais-salesman-panel');

    // v1.0.2: draggable launcher with mouse/touch support and persistent position.
    const peaisPositionKey = 'peais_salesman_position';

    const peaisClampPosition = function (x, y) {
        const rect = toggle.getBoundingClientRect();
        const margin = 12;
        return {
            x: Math.min(Math.max(margin, x), Math.max(margin, window.innerWidth - rect.width - margin)),
            y: Math.min(Math.max(margin, y), Math.max(margin, window.innerHeight - rect.height - margin))
        };
    };

    const peaisApplyPosition = function (x, y, persist) {
        const pos = peaisClampPosition(x, y);
        toggle.style.position = 'fixed';
        toggle.style.left = pos.x + 'px';
        toggle.style.top = pos.y + 'px';
        toggle.style.right = 'auto';
        toggle.style.bottom = 'auto';

        if (persist) {
            try {
                localStorage.setItem(peaisPositionKey, JSON.stringify(pos));
            } catch (e) {}
        }
        return pos;
    };

    const peaisPositionPanel = function () {
        if (panel.hidden) return;
        const t = toggle.getBoundingClientRect();
        const p = panel.getBoundingClientRect();
        const gap = 10;
        const margin = 10;

        let top = t.top - p.height - gap;
        if (top < margin) top = t.bottom + gap;

        let left = t.right - p.width;
        left = Math.max(margin, Math.min(left, window.innerWidth - p.width - margin));
        top = Math.max(margin, Math.min(top, window.innerHeight - p.height - margin));

        panel.style.position = 'fixed';
        panel.style.left = Math.round(left) + 'px';
        panel.style.top = Math.round(top) + 'px';
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
    };

    try {
        const saved = JSON.parse(localStorage.getItem(peaisPositionKey) || 'null');
        if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.y)) {
            peaisApplyPosition(saved.x, saved.y, false);
        }
    } catch (e) {}

    let peaisDrag = null;
    let peaisMoved = false;

    toggle.addEventListener('pointerdown', function (event) {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        const rect = toggle.getBoundingClientRect();
        peaisDrag = {
            id: event.pointerId,
            offsetX: event.clientX - rect.left,
            offsetY: event.clientY - rect.top,
            startX: event.clientX,
            startY: event.clientY
        };
        peaisMoved = false;
        try { toggle.setPointerCapture(event.pointerId); } catch (e) {}
    });

    toggle.addEventListener('pointermove', function (event) {
        if (!peaisDrag || event.pointerId !== peaisDrag.id) return;

        const dx = event.clientX - peaisDrag.startX;
        const dy = event.clientY - peaisDrag.startY;
        if (!peaisMoved && Math.hypot(dx, dy) < 6) return;

        peaisMoved = true;
        peaisApplyPosition(
            event.clientX - peaisDrag.offsetX,
            event.clientY - peaisDrag.offsetY,
            true
        );
        if (!panel.hidden) peaisPositionPanel();
        event.preventDefault();
    });

    const peaisFinishDrag = function (event) {
        if (!peaisDrag || event.pointerId !== peaisDrag.id) return;
        try { toggle.releasePointerCapture(event.pointerId); } catch (e) {}
        peaisDrag = null;
        setTimeout(function () { peaisMoved = false; }, 0);
    };

    toggle.addEventListener('pointerup', peaisFinishDrag);
    toggle.addEventListener('pointercancel', peaisFinishDrag);

    // Prevent a drag gesture from also opening the chat.
    toggle.addEventListener('click', function (event) {
        if (peaisMoved) {
            event.preventDefault();
            event.stopImmediatePropagation();
        }
    }, true);

    window.addEventListener('resize', function () {
        const rect = toggle.getBoundingClientRect();
        peaisApplyPosition(rect.left, rect.top, true);
        peaisPositionPanel();
    });


	const close = document.getElementById('peais-salesman-close');
	const form = document.getElementById('peais-salesman-form');
	const input = document.getElementById('peais-salesman-input');
	const chat = document.getElementById('peais-salesman-chat');
	let conversation = [];

	function addMessage(text, type) {
		if (!text) return;
		const bubble = document.createElement('div');
		bubble.className = 'peais-message peais-' + type;
		bubble.textContent = text;
		chat.appendChild(bubble);
		chat.scrollTop = chat.scrollHeight;
	}

	function addProducts(products) {
		if (!Array.isArray(products) || !products.length) return;
		const wrapper = document.createElement('div');
		wrapper.className = 'peais-products';

		products.forEach(function (product) {
			const card = document.createElement('div');
			card.className = 'peais-product';

			const link = document.createElement('a');
			link.href = product.url || '#';
			link.className = 'peais-product-image';

			const image = document.createElement('img');
			image.src = product.image || '';
			image.alt = product.name || '';
			image.loading = 'lazy';
			link.appendChild(image);

			const content = document.createElement('div');
			content.className = 'peais-product-content';

			const name = document.createElement('strong');
			name.textContent = product.name || '';

			const price = document.createElement('div');
			price.className = 'peais-product-price';
			price.innerHTML = product.price || '';

			content.appendChild(name);
			content.appendChild(price);

			if (product.reason) {
				const reason = document.createElement('small');
				reason.textContent = product.reason;
				content.appendChild(reason);
			}

			const actions = document.createElement('div');
			actions.className = 'peais-product-actions';

			const view = document.createElement('a');
			view.href = product.url || '#';
			view.textContent = 'View Product';
			view.className = 'peais-view';
			actions.appendChild(view);

			if (product.id) {
				const cart = document.createElement('a');
				cart.href = '?add-to-cart=' + encodeURIComponent(product.id);
				cart.textContent = 'Add to Cart';
				cart.className = 'peais-cart';
				actions.appendChild(cart);
			}

			content.appendChild(actions);
			card.appendChild(link);
			card.appendChild(content);
			wrapper.appendChild(card);
		});

		chat.appendChild(wrapper);
		chat.scrollTop = chat.scrollHeight;
	}

	toggle.addEventListener('click', function () {
		const shouldOpen = panel.hidden;
		panel.hidden = !shouldOpen;
		toggle.setAttribute('aria-expanded', String(shouldOpen));
		if (shouldOpen) { peaisPositionPanel(); input.focus(); }
	});

	// Keep the close/minimize control reliable even when a theme changes button styles.
	close.addEventListener('click', function (event) {
		event.preventDefault();
		event.stopPropagation();
		panel.hidden = true;
		toggle.setAttribute('aria-expanded', 'false');
	});

	form.addEventListener('submit', async function (event) {
		event.preventDefault();
		const text = input.value.trim();
		if (!text) return;

		addMessage(text, 'user');
		conversation.push({ role: 'user', content: text });
		input.value = '';
		input.disabled = true;

		const loading = document.createElement('div');
		loading.className = 'peais-message peais-assistant peais-loading';
		loading.textContent = 'Thinking…';
		chat.appendChild(loading);

		const formData = new FormData();
		formData.append('action', 'peais_chat');
		formData.append('nonce', PEAISalesman.nonce);
		formData.append('conversation', JSON.stringify(conversation));

		try {
			const response = await fetch(PEAISalesman.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: formData });
			const data = await response.json();
			loading.remove();

			if (!data.success || !data.data) {
				addMessage(data && data.data && data.data.message ? data.data.message : 'Sorry, something went wrong. Please try again.', 'assistant');
				return;
			}

			if (data.data.message) {
				addMessage(data.data.message, 'assistant');
				conversation.push({ role: 'assistant', content: data.data.message });
			}

			if (data.data.question) {
				addMessage(data.data.question, 'assistant');
				conversation.push({ role: 'assistant', content: data.data.question });
			}

			addProducts(data.data.products || []);
		} catch (error) {
			loading.remove();
			addMessage('The sales assistant is temporarily unavailable. Please try again.', 'assistant');
		} finally {
			input.disabled = false;
			input.focus();
		}
	});
}());
