<?php
defined( 'ABSPATH' ) || exit;

/**
 * WordPress AI Client integration for AI Salesman.
 *
 * @since 1.0.2
 */
class PEAIS_AI {

	/**
	 * Whether the WordPress AI Client is enabled for this plugin.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) get_option( 'peais_enable_ai', 0 ) && function_exists( 'wp_ai_client_prompt' );
	}

	/**
	 * Generate a structured sales response.
	 *
	 * @param array $conversation Sanitized conversation.
	 * @param array $products      Candidate products.
	 * @return array|WP_Error
	 */
	public static function answer( $conversation, $products ) {
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return new WP_Error( 'peais_ai_unavailable', 'The WordPress AI Client is not available.' );
		}

		if ( empty( $products ) ) {
			return new WP_Error( 'peais_ai_unavailable', 'No products are available for AI recommendations.' );
		}

		$catalog = array();

		foreach ( $products as $product ) {
			$catalog[] = array(
				'id'    => (int) $product['id'],
				'name'  => wp_strip_all_tags( $product['name'] ),
				'price' => (float) $product['price'],
				'stock' => (int) $product['stock'],
			);
		}

		$prompt = wp_json_encode(
			array(
				'conversation' => $conversation,
				'catalog'     => $catalog,
			)
		);

		$system_instruction = 'You are a helpful ecommerce AI salesperson. Understand customer intent, budget, occasion, recipient, preferences and objections. Recommend only products from the supplied catalog. Never invent products, prices or IDs. Ask at most one short clarification question when necessary. Return JSON with keys question, message, product_ids, reasons.';

		$schema = array(
			'type'       => 'object',
			'properties' => array(
				'question'    => array( 'type' => 'string' ),
				'message'     => array( 'type' => 'string' ),
				'product_ids' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'integer' ),
				),
				'reasons'     => array(
					'type'                 => 'object',
					'additionalProperties' => array( 'type' => 'string' ),
				),
			),
			'required'   => array( 'question', 'message', 'product_ids', 'reasons' ),
		);

		$builder = wp_ai_client_prompt( $prompt )
			->using_system_instruction( $system_instruction )
			->using_temperature( 0.2 )
			->as_json_response( $schema );

		$model = sanitize_text_field( get_option( 'peais_ai_model', '' ) );
		if ( '' !== $model ) {
			$builder->using_model_preference( $model );
		}

		$text = $builder->generate_text();

		if ( is_wp_error( $text ) ) {
			return $text;
		}

		$text = trim( (string) $text );
		$data = json_decode( $text, true );

		if ( ! is_array( $data ) ) {
			return new WP_Error( 'peais_ai_json', 'AI returned an invalid response.' );
		}

		$allowed = array_map( 'intval', wp_list_pluck( $catalog, 'id' ) );
		$ids     = array();

		foreach ( (array) ( $data['product_ids'] ?? array() ) as $id ) {
			$id = absint( $id );
			if ( in_array( $id, $allowed, true ) ) {
				$ids[] = $id;
			}
		}

		$reasons = array();
		foreach ( (array) ( $data['reasons'] ?? array() ) as $id => $reason ) {
			$id = absint( $id );
			if ( in_array( $id, $allowed, true ) ) {
				$reasons[ $id ] = sanitize_text_field( $reason );
			}
		}

		return array(
			'question' => sanitize_text_field( $data['question'] ?? '' ),
			'message'  => sanitize_text_field( $data['message'] ?? '' ),
			'ids'      => array_values( array_unique( $ids ) ),
			'reasons'  => $reasons,
		);
	}
}
