<?php
defined( 'ABSPATH' ) || exit;

class PEAIS_Plugin {
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_footer', array( __CLASS__, 'footer_widget' ) );
		add_shortcode( 'peais_salesman', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_ajax_peais_chat', array( __CLASS__, 'chat' ) );
		add_action( 'wp_ajax_nopriv_peais_chat', array( __CLASS__, 'chat' ) );
		add_action( 'save_post_product', array( __CLASS__, 'product_changed' ) );
		add_action( 'deleted_post', array( __CLASS__, 'product_deleted' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
	}

	public static function activate() {
		update_option( 'peais_catalog_dirty', 1, false );
		add_option( 'peais_enable_ai', 0, '', false );
		add_option( 'peais_ai_model', '', '', false );
		add_option( 'peais_monthly_conversations', 100, '', false );
	}

	public static function deactivate() {}

	public static function product_changed( $post_id ) {
		if ( ! wp_is_post_revision( $post_id ) ) PEAIS_Catalog::invalidate();
	}

	public static function product_deleted( $post_id ) {
		if ( 'product' === get_post_type( $post_id ) ) PEAIS_Catalog::invalidate();
	}

	public static function assets() {
		if ( ! class_exists( 'WooCommerce' ) ) return;

		wp_enqueue_style( 'peais-ai-salesman', PEAIS_URL . 'assets/css/ai-salesman.css', array(), PEAIS_VERSION );
		wp_enqueue_script( 'peais-ai-salesman', PEAIS_URL . 'assets/js/ai-salesman.js', array(), PEAIS_VERSION, true );
		wp_localize_script(
			'peais-ai-salesman',
			'PEAISalesman',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'peais_chat' ),
			)
		);
	}

	public static function footer_widget() {
		if ( ! class_exists( 'WooCommerce' ) ) return;
		?>
		<div id="peais-salesman-root">
			<button type="button" id="peais-salesman-toggle" aria-expanded="false"><span class="peais-icon">🤖</span><span>AI Salesman</span></button>
			<div id="peais-salesman-panel" hidden>
				<div class="peais-header">
					<div><strong>AI Salesman</strong><small>Your 24/7 shopping assistant</small></div>
					<button type="button" id="peais-salesman-close" aria-label="Close">×</button>
				</div>
				<div id="peais-salesman-chat" aria-live="polite">
					<div class="peais-message peais-assistant">Hi! 👋 I'm your AI Salesman. Tell me what you're looking for, your budget, or who you're shopping for.</div>
				</div>
				<form id="peais-salesman-form">
					<input type="text" id="peais-salesman-input" autocomplete="off" maxlength="500" placeholder="e.g. gift for my wife under ₹2000" />
					<button type="submit">Send</button>
				</form>
			</div>
		</div>
		<?php
	}

	public static function shortcode() {
		ob_start();
		self::footer_widget();
		return ob_get_clean();
	}

	public static function conversation_count() {
		return absint( get_option( 'peais_conversations_' . gmdate( 'Ym' ), 0 ) );
	}

	public static function increment_conversation_count() {
		$key = 'peais_conversations_' . gmdate( 'Ym' );
		$count = self::conversation_count() + 1;
		update_option( $key, $count, false );
		return $count;
	}

	public static function chat() {
		check_ajax_referer( 'peais_chat', 'nonce' );

		if ( ! class_exists( 'WooCommerce' ) ) {
			wp_send_json_error( array( 'message' => 'WooCommerce is required for AI Salesman.' ) );
		}

		$conversation = array();
		if ( isset( $_POST['conversation'] ) ) {
			if ( is_string( $_POST['conversation'] ) ) {
				$raw     = sanitize_textarea_field( wp_unslash( $_POST['conversation'] ) );
				$decoded = json_decode( $raw, true );
				if ( is_array( $decoded ) ) {
					$conversation = array_slice( $decoded, -10 );
				}
			} elseif ( is_array( $_POST['conversation'] ) ) {
				$raw          = map_deep( wp_unslash( $_POST['conversation'] ), 'sanitize_text_field' );
				$conversation = array_slice( $raw, -10 );
			}
		}

		$clean = array();
		foreach ( $conversation as $message ) {
			if ( ! is_array( $message ) ) continue;
			$role = ( isset( $message['role'] ) && 'assistant' === $message['role'] ) ? 'assistant' : 'user';
			$content = isset( $message['content'] ) ? sanitize_text_field( $message['content'] ) : '';
			if ( '' !== $content ) $clean[] = array( 'role' => $role, 'content' => mb_substr( $content, 0, 500 ) );
		}

		$last = '';
		foreach ( array_reverse( $clean ) as $message ) {
			if ( 'user' === $message['role'] ) { $last = $message['content']; break; }
		}

		if ( '' === $last ) wp_send_json_error( array( 'message' => 'Please tell me what you are looking for.' ) );

		$limit = absint( get_option( 'peais_monthly_conversations', 100 ) );
		$candidates = PEAIS_Catalog::search( $last, 12 );

		if ( $limit > 0 && self::conversation_count() >= $limit ) {
			wp_send_json_success( array(
				'message' => 'The free AI conversation limit for this month has been reached. You can still browse matching products below.',
				'question' => '',
				'products' => self::format_products( $candidates ),
			) );
		}

		self::increment_conversation_count();

		$catalog = PEAIS_Catalog::get();
		if ( empty( $catalog ) ) wp_send_json_success( array( 'message' => 'No published WooCommerce products are available yet.', 'question' => '', 'products' => array() ) );

		if ( empty( $candidates ) ) $candidates = array_slice( array_values( $catalog ), 0, 12 );

		$answer = array();
		if ( PEAIS_AI::enabled() ) {
			$answer = PEAIS_AI::answer( $clean, $candidates );
			if ( is_wp_error( $answer ) ) $answer = array();
		}

		$ids = ! empty( $answer['ids'] ) ? array_map( 'absint', $answer['ids'] ) : array_map( 'absint', wp_list_pluck( array_slice( $candidates, 0, 6 ), 'id' ) );
		$products = array();

		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product || 'publish' !== get_post_status( $id ) ) continue;
			$products[] = array(
				'id' => $id,
				'name' => wp_strip_all_tags( $product->get_name() ),
				'price' => wp_strip_all_tags( $product->get_price_html() ),
				'url' => esc_url_raw( get_permalink( $id ) ),
				'image' => esc_url_raw( wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' ) ?: wc_placeholder_img_src() ),
				'reason' => isset( $answer['reasons'][ $id ] ) ? $answer['reasons'][ $id ] : '',
			);
		}

		$message = ! empty( $answer['message'] ) ? $answer['message'] : ( ! empty( $products ) ? 'Here are some products that may be a good match for you.' : 'I could not find a close match. Try describing what you need another way.' );

		wp_send_json_success( array(
			'message' => $message,
			'question' => ! empty( $answer['question'] ) ? $answer['question'] : '',
			'products' => $products,
		) );
	}

	private static function format_products( $products ) {
		$formatted = array();
		foreach ( $products as $item ) {
			$product = wc_get_product( absint( $item['id'] ) );
			if ( ! $product ) continue;
			$formatted[] = array(
				'id' => $product->get_id(),
				'name' => wp_strip_all_tags( $product->get_name() ),
				'price' => wp_strip_all_tags( $product->get_price_html() ),
				'url' => esc_url_raw( get_permalink( $product->get_id() ) ),
				'image' => esc_url_raw( wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' ) ?: wc_placeholder_img_src() ),
				'reason' => '',
			);
		}
		return $formatted;
	}

	public static function admin_menu() {
		add_options_page( 'AI Salesman', 'AI Salesman', 'manage_options', 'peais-ai-salesman', array( __CLASS__, 'settings' ) );
	}

	public static function settings() {
		if ( ! current_user_can( 'manage_options' ) ) return;

		if ( isset( $_POST['peais_save'] ) ) {
			check_admin_referer( 'peais_save_settings' );
			update_option( 'peais_enable_ai', ! empty( $_POST['enable_ai'] ) ? 1 : 0 );
			update_option( 'peais_ai_model', sanitize_text_field( wp_unslash( $_POST['ai_model'] ?? '' ) ) );
			update_option( 'peais_monthly_conversations', absint( $_POST['monthly_limit'] ?? 100 ) );
			echo '<div class="notice notice-success is-dismissible"><p>AI Salesman settings saved.</p></div>';
		}

		$catalog_count = count( PEAIS_Catalog::get() );
		?>
		<div class="wrap">
			<h1>Publicity Expert AI Salesman</h1>
			<p><strong>Free Version 1.0.2</strong> — Turn your WooCommerce store into a 24/7 AI sales assistant.</p>
			<form method="post">
				<?php wp_nonce_field( 'peais_save_settings' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row">Enable AI Salesman</th><td><label><input type="checkbox" name="enable_ai" value="1" <?php checked( get_option( 'peais_enable_ai', 0 ), 1 ); ?> /> Enable AI-powered conversations</label><p class="description">When enabled, the plugin uses the WordPress AI Client. Configure an AI provider in Settings &rarr; Connectors.</p></td></tr>
					<tr><th scope="row">Preferred AI model</th><td><input type="text" name="ai_model" class="regular-text" value="<?php echo esc_attr( get_option( 'peais_ai_model', '' ) ); ?>" /><p class="description">Optional model preference. Leave blank to let the WordPress AI Client choose a compatible configured model.</p></td></tr>
					<tr><th scope="row">Free monthly conversations</th><td><input type="number" min="0" step="1" name="monthly_limit" value="<?php echo esc_attr( get_option( 'peais_monthly_conversations', 100 ) ); ?>" /><p class="description">Set 0 for unlimited local testing.</p></td></tr>
					<tr><th scope="row">Catalog</th><td><strong><?php echo esc_html( $catalog_count ); ?></strong> published products indexed.</td></tr>
				</table>
				<p><button type="submit" name="peais_save" value="1" class="button button-primary">Save Settings</button></p>
			</form>
			<hr />
			<h2>Shortcode</h2>
			<p>Use <code>[peais_salesman]</code> to display the widget inside a page or template.</p>
			<h2>Free Version</h2>
			<ul><li>Conversational product assistance</li><li>Budget-aware discovery</li><li>Product recommendations</li><li>Recommendation explanations</li><li>Product links and add-to-cart</li></ul>
		</div>
		<?php
	}
}
