<?php
defined( 'ABSPATH' ) || exit;

class PEAIS_Catalog {
	private static $option = 'peais_product_catalog';

	public static function invalidate() {
		update_option( 'peais_catalog_dirty', 1, false );
	}

	public static function build() {
		if ( ! class_exists( 'WooCommerce' ) ) return 0;
		$products = wc_get_products( array(
			'status' => 'publish',
			'limit' => -1,
			'return' => 'objects',
		) );
		$catalog = array();

		foreach ( $products as $product ) {
			$id = $product->get_id();
			$categories = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'names' ) );
			$tags = wp_get_post_terms( $id, 'product_tag', array( 'fields' => 'names' ) );
			$catalog[ $id ] = array(
				'id' => $id,
				'name' => wp_strip_all_tags( $product->get_name() ),
				'description' => wp_strip_all_tags( $product->get_short_description() . ' ' . $product->get_description() ),
				'sku' => sanitize_text_field( $product->get_sku() ),
				'price' => (float) $product->get_price(),
				'stock' => $product->is_in_stock() ? 1 : 0,
				'categories' => array_map( 'sanitize_text_field', $categories ),
				'tags' => array_map( 'sanitize_text_field', $tags ),
				'rating' => (float) $product->get_average_rating(),
			);
		}
		update_option( self::$option, $catalog, false );
		update_option( 'peais_catalog_built_at', current_time( 'mysql' ), false );
		delete_option( 'peais_catalog_dirty' );
		return count( $catalog );
	}

	public static function get() {
		$catalog = get_option( self::$option, array() );
		if ( empty( $catalog ) || get_option( 'peais_catalog_dirty', 0 ) ) {
			self::build();
			$catalog = get_option( self::$option, array() );
		}
		return is_array( $catalog ) ? $catalog : array();
	}

	public static function search( $query, $limit = 12 ) {
		$catalog = self::get();
		$query = strtolower( sanitize_text_field( $query ) );
		$tokens = array_filter( preg_split( '/\s+/', $query ), 'strlen' );
		$stop = array( 'i','me','my','a','an','the','for','to','with','want','need','show','find','looking','please','something','under','below','upto','up','than','less','price','rs','inr' );
		$synonyms = array(
			'ladies' => array( 'women','woman','female' ),
			'women' => array( 'ladies','woman','female' ),
			'men' => array( 'mens','man','male' ),
			'kids' => array( 'children','child' ),
			'gift' => array( 'gifts','present' ),
			'shoe' => array( 'shoes','footwear' ),
			'dress' => array( 'dresses','outfit' ),
			'jewellery' => array( 'jewelry','ornament' ),
			'jewelry' => array( 'jewellery','ornament' ),
		);
		$expanded = array();

		foreach ( $tokens as $token ) {
			if ( in_array( $token, $stop, true ) ) continue;
			$expanded[] = $token;
			if ( isset( $synonyms[ $token ] ) ) $expanded = array_merge( $expanded, $synonyms[ $token ] );
		}

		$max_price = null;
		if ( preg_match( '/(?:under|below|less than|upto|up to|within)\s*(?:₹|rs\.?|inr)?\s*([0-9][0-9,]*)/i', $query, $match ) ) {
			$max_price = (float) str_replace( ',', '', $match[1] );
		}

		$results = array();
		foreach ( $catalog as $item ) {
			if ( null !== $max_price && $item['price'] > 0 && $item['price'] > $max_price ) continue;
			$search_text = strtolower( $item['name'] . ' ' . $item['description'] . ' ' . $item['sku'] . ' ' . implode( ' ', $item['categories'] ) . ' ' . implode( ' ', $item['tags'] ) );
			$name_text = strtolower( $item['name'] );
			$score = 0;

			foreach ( $expanded as $token ) {
				if ( false !== strpos( $search_text, $token ) ) $score += 2;
				if ( false !== strpos( $name_text, $token ) ) $score += 4;
			}
			if ( $item['stock'] ) $score += 1;
			$score += min( 2, $item['rating'] / 2.5 );

			if ( $score > 0 ) {
				$results[] = array(
					'id' => (int) $item['id'],
					'name' => $item['name'],
					'price' => $item['price'],
					'stock' => (int) $item['stock'],
					'score' => $score,
				);
			}
		}

		usort( $results, function( $a, $b ) { return $b['score'] <=> $a['score']; } );
		return array_slice( $results, 0, absint( $limit ) );
	}
}
