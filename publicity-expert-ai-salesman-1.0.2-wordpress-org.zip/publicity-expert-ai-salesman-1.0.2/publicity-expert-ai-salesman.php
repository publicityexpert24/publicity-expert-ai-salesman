<?php
/**
 * Plugin Name: Publicity Expert AI Salesman
 * Plugin URI: https://publicityexpert.in/ai-salesman/
 * Description: AI sales assistant for WooCommerce that helps shoppers discover products, compare options, shop by budget, and get recommendations.
 * Version: 1.0.2
 * Author: PUBLICITY EXPERT
 * Author URI: https://publicityexpert.in/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires Plugins: woocommerce
 * Text Domain: publicity-expert-ai-salesman
 * Requires at least: 7.0
 * Requires PHP: 7.4
 */
defined( 'ABSPATH' ) || exit;

define( 'PEAIS_VERSION', '1.0.2' );
define( 'PEAIS_FILE', __FILE__ );
define( 'PEAIS_DIR', plugin_dir_path( __FILE__ ) );
define( 'PEAIS_URL', plugin_dir_url( __FILE__ ) );

require_once PEAIS_DIR . 'includes/class-peais-catalog.php';
require_once PEAIS_DIR . 'includes/class-peais-ai.php';
require_once PEAIS_DIR . 'includes/class-peais-plugin.php';

register_activation_hook( __FILE__, array( 'PEAIS_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'PEAIS_Plugin', 'deactivate' ) );
add_action( 'plugins_loaded', array( 'PEAIS_Plugin', 'init' ) );
