=== Publicity Expert AI Salesman ===
Contributors: publicityexpert
Tags: woocommerce, ai, sales, chatbot, product-recommendations
Requires at least: 7.0
Tested up to: 7.1
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI sales assistant for WooCommerce that helps shoppers discover products, shop by budget, compare options, and get recommendations.

== Description ==

Publicity Expert AI Salesman adds a conversational shopping assistant to WooCommerce stores. Customers can describe what they need, mention a budget or occasion, and receive matching products from the store catalog.

The plugin works with local WooCommerce product discovery and can optionally use the OpenAI API for AI-generated recommendations. AI is disabled by default and requires the store owner to configure an OpenAI API key.

== Features ==

* Conversational product assistance.
* Natural-language product discovery.
* Budget-aware product search.
* Gift and occasion-oriented requests.
* Product recommendations and explanations.
* Product links and add-to-cart actions.
* Draggable floating AI Salesman launcher.
* Remembers the launcher's position in the browser.
* Mobile-responsive interface.
* WooCommerce catalog indexing with local fallback search.
* Optional AI-powered responses.
* Basic monthly conversation limit.
* WordPress nonce protection, input sanitization, and output escaping.
* Shortcode: `[peais_salesman]`.

== External Services ==

When AI features are enabled, this plugin uses the WordPress AI Client included in WordPress 7.0 and later. The WordPress AI Client sends the prompts and product information needed for the requested AI response to the AI provider configured by the site administrator.

The plugin does not directly select or connect to a specific AI provider. Site administrators manage AI provider connections and credentials through the WordPress Connectors system.

The plugin may send:
* The customer's conversation messages submitted to the AI Salesman.
* Relevant product names, prices, stock information, and product IDs from the candidate catalog.
* Instructions required to generate the AI Salesman response.

The information is sent only when AI features are enabled and an AI provider is configured.

== Privacy ==

The plugin's local product search does not require an external AI service. When AI is enabled, conversation and relevant product catalog information may be processed by the AI provider configured by the site administrator through WordPress Connectors. Merchants should review the privacy terms of their configured provider and provide any disclosures required for their site and jurisdiction.

The plugin does not intentionally send the site's AI provider credentials to the browser.



The plugin does not require shoppers to create an account with Publicity Expert. Conversation messages are processed in the browser and sent to the site's WordPress AJAX endpoint. When the optional AI feature is enabled, the relevant conversation and candidate product information described in the External Services section is sent to OpenAI.

The plugin stores the configured OpenAI API key in a WordPress option on the site and does not expose it in the public widget. The plugin also stores a site-wide monthly conversation counter for its basic usage limit.

Store owners should update their site's privacy policy and obtain any permissions or notices required for their jurisdiction and business model.

== Installation ==

1. Install and activate WooCommerce.
2. Upload the plugin through **Plugins > Add New > Upload Plugin**.
3. Activate **Publicity Expert AI Salesman**.
4. Go to **Settings > AI Salesman**.
5. Optional: enable AI and enter an OpenAI API key.
6. Visit the storefront and use the **AI Salesman** launcher, or place `[peais_salesman]` in a page or template.

== Frequently Asked Questions ==

= Does the plugin require OpenAI? =

No. Local WooCommerce product discovery works without an OpenAI API key. AI-powered responses require the optional OpenAI integration to be enabled.

= Does the plugin require WooCommerce? =

Yes. WooCommerce is required because the assistant works with the store's product catalog.

= Can I move the AI Salesman button? =

Yes. Drag the launcher with a mouse or touch input. Its position is remembered by the browser.

= Where do I configure the plugin? =

Go to **Settings > AI Salesman** in WordPress admin.

= Does the plugin send data to external services? =

Only when the optional AI feature is enabled. See the **External Services** section for details.

== Changelog ==

= 1.0.2 =
* Added draggable AI Salesman launcher with mouse and touch support.
* Remembers the launcher's selected position in the browser.
* Keeps the launcher inside the viewport.
* Chat panel follows the launcher position.
* Improved colorful launcher styling.
* Fixed AI Salesman window minimize and close behavior.

= 1.0.0 =
* Initial free release.
